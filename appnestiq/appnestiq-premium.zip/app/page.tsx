'use client'

import Image from "next/image"
import { motion } from "framer-motion"
import Link from "next/link"

export default function Home() {
  return (
    <main className="min-h-screen bg-[#0f0c1b] text-white">
      <section className="h-screen flex flex-col justify-center items-center text-center px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="mb-4"
        >
          <Image src="/logo.png" alt="Appnestiq Logo" width={96} height={96} />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.8 }}
          className="text-5xl md:text-6xl font-bold text-white"
        >
          Build your future
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="mt-4 text-lg text-white/70 max-w-xl"
        >
          Custom software. Premium delivery. Equity-first thinking.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.9, duration: 0.6 }}
          className="mt-8"
        >
          <Link
            href="#contact"
            className="bg-[#c084fc] hover:bg-[#a855f7] text-black font-semibold py-3 px-6 rounded-full text-lg transition"
          >
            Let’s Talk
          </Link>
        </motion.div>
      </section>
    </main>
  )
}
